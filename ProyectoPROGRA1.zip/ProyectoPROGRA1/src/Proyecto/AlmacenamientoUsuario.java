/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;
import javax.swing.JOptionPane;

/**
 *
 * @author XSF
 */
public class AlmacenamientoUsuario {
    public String Nombre ;
    public String Apellido;
    public String Usuario;
    public String Correo;
    public String Password;
    
    public AlmacenamientoUsuario(){
    
    }
    public AlmacenamientoUsuario(String Nombre, String Apellido, String Usuario, String Correo, String Password ){
       this.Nombre = Nombre;
       this.Apellido = Apellido;
       this.Usuario = Usuario;
       this.Correo = Correo;
       this.Password = Password;
       
    }

class AlmacenamientoUsuarios {
   AlmacenamientoUsuario[] usuarios;
    int cantidadUsuarios;
   
    public AlmacenamientoUsuarios(int capacidad) {
        usuarios = new AlmacenamientoUsuario[capacidad];
        cantidadUsuarios = 100;
       }
   
    
   }
  // Getters y Setters

    public String getNombre(){
     return Nombre;
    }
    
    public void setNombre(String Nombre){
      this.Nombre = Nombre;
    }
    
    public String getApellido(){
      return Apellido;
    }
    
    public void setApellido(String Apellido){
      this.Apellido = Apellido;
    }
    
    public String getUsuario(){
      return Usuario;
    }
    
    public void setUsuario(String Usuario){
      this.Usuario = Usuario;
    }
    public String getCorreo(){
      return Correo;
    }
    
    //Valida que se ingrese un correo con @ que sea valido
    
    public void setCorreo(String Correo){
     if (!Correo.contains("@")){
         JOptionPane.showInternalMessageDialog(null, "Ha ingresado un correo invalido");
         this.Correo = "Correo Invalido";
         
     } else{
         this.Correo = Correo;
     }
    }
    
    public String getPassword(){
     return Password;
    }
    
    public void setPassword(String Password){
      this.Password = Password; 
    }
    
}
