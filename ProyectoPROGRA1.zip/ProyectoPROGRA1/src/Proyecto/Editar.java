/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;
import Proyecto.Evento;
/**
 *
 * @author XSF
 */
public class Editar {
    public void editarNombre(Evento evento, String nuevoNombre) {
        evento.setNombre(nuevoNombre);
    }

    public void editarCiudad(Evento evento, String nuevaCiudad) {
        evento.setCiudad(nuevaCiudad);
    }

    public void editarDireccion(Evento evento, String nuevaDireccion) {
        evento.setDireccion(nuevaDireccion);
    }

    public void editarCategoria(Evento evento, String nuevaCategoria) {
        evento.setCategoria(nuevaCategoria);
    }

    public void editarFecha(Evento evento, String nuevaFecha) {
        evento.setFecha(nuevaFecha);
    }

    public void editarCapacidadTotal(Evento evento, int nuevaCapacidadTotal) {
        evento.setCapacidadTotal(nuevaCapacidadTotal);
    } 
}
