  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Proyecto;
import javax.swing.JOptionPane;

import java.awt.Color;


public class Interfaz3 extends javax.swing.JFrame {
    
    //Variables para conocer el Eje del cursor/parala barra de arriba
    int xMouse,yMouse;
            
    
    
    public Interfaz3() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background = new javax.swing.JPanel();
        NombreDeLaEmpresa = new javax.swing.JLabel();
        FondoTay = new javax.swing.JLabel();
        textIniciarSesion = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        BotonEvento1 = new javax.swing.JPanel();
        TextEventmes1 = new javax.swing.JLabel();
        TextEventdia1 = new javax.swing.JLabel();
        TextEvento1Fecha = new javax.swing.JLabel();
        TextEvento1 = new javax.swing.JLabel();
        PanelHerramientas = new javax.swing.JPanel();
        BotonCerrar = new javax.swing.JPanel();
        TextCerrarX = new javax.swing.JLabel();
        BotonEvento2 = new javax.swing.JPanel();
        TextEventmes2 = new javax.swing.JLabel();
        TextEventdia2 = new javax.swing.JLabel();
        TextEvento1Fecha1 = new javax.swing.JLabel();
        TextEvento2 = new javax.swing.JLabel();
        BotonEvento3 = new javax.swing.JPanel();
        TextEventmes3 = new javax.swing.JLabel();
        TextEventdia3 = new javax.swing.JLabel();
        TextEvento1Fecha2 = new javax.swing.JLabel();
        TextEvento3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        Background.setBackground(new java.awt.Color(255, 255, 255));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NombreDeLaEmpresa.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        NombreDeLaEmpresa.setForeground(new java.awt.Color(255, 255, 255));
        NombreDeLaEmpresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NombreDeLaEmpresa.setText("Productora de eventos Producciones Palace");
        NombreDeLaEmpresa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Background.add(NombreDeLaEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 100, 340, 20));

        FondoTay.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/TaylorConcert.jpg"))); // NOI18N
        FondoTay.setText("jLabel1");
        Background.add(FondoTay, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 490, 530));

        textIniciarSesion.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 36)); // NOI18N
        textIniciarSesion.setText("EVENTOS");
        Background.add(textIniciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 310, -1));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 310, -1));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 310, -1));

        BotonEvento1.setBackground(new java.awt.Color(43, 50, 78));
        BotonEvento1.setForeground(new java.awt.Color(0, 0, 102));
        BotonEvento1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEvento1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonEvento1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonEvento1MouseExited(evt);
            }
        });

        TextEventmes1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventmes1.setForeground(new java.awt.Color(255, 255, 255));
        TextEventmes1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventmes1.setText("Aug");
        TextEventmes1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        TextEventdia1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventdia1.setForeground(new java.awt.Color(255, 255, 255));
        TextEventdia1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventdia1.setText("24");
        TextEventdia1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonEvento1Layout = new javax.swing.GroupLayout(BotonEvento1);
        BotonEvento1.setLayout(BotonEvento1Layout);
        BotonEvento1Layout.setHorizontalGroup(
            BotonEvento1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes1, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
            .addComponent(TextEventdia1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BotonEvento1Layout.setVerticalGroup(
            BotonEvento1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonEvento1Layout.createSequentialGroup()
                .addComponent(TextEventmes1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextEventdia1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(BotonEvento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 70, 60));

        TextEvento1Fecha.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextEvento1Fecha.setText("Taylor Swift | The Eras Tour");
        Background.add(TextEvento1Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, -1, -1));

        TextEvento1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextEvento1.setForeground(new java.awt.Color(102, 102, 102));
        TextEvento1.setText("Thu, 9 PM | Foro Sol México");
        Background.add(TextEvento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, -1, -1));

        PanelHerramientas.setBackground(new java.awt.Color(255, 255, 255));
        PanelHerramientas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PanelHerramientasMouseDragged(evt);
            }
        });
        PanelHerramientas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PanelHerramientasMousePressed(evt);
            }
        });

        BotonCerrar.setBackground(new java.awt.Color(43, 50, 78));

        TextCerrarX.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        TextCerrarX.setForeground(new java.awt.Color(255, 255, 255));
        TextCerrarX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCerrarX.setText("X");
        TextCerrarX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TextCerrarX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BotonCerrarLayout = new javax.swing.GroupLayout(BotonCerrar);
        BotonCerrar.setLayout(BotonCerrarLayout);
        BotonCerrarLayout.setHorizontalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );
        BotonCerrarLayout.setVerticalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout PanelHerramientasLayout = new javax.swing.GroupLayout(PanelHerramientas);
        PanelHerramientas.setLayout(PanelHerramientasLayout);
        PanelHerramientasLayout.setHorizontalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 833, Short.MAX_VALUE))
        );
        PanelHerramientasLayout.setVerticalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(PanelHerramientas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 30));

        BotonEvento2.setBackground(new java.awt.Color(43, 50, 78));
        BotonEvento2.setForeground(new java.awt.Color(0, 0, 102));
        BotonEvento2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEvento2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonEvento2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonEvento2MouseExited(evt);
            }
        });

        TextEventmes2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventmes2.setForeground(new java.awt.Color(255, 255, 255));
        TextEventmes2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventmes2.setText("Aug");
        TextEventmes2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        TextEventdia2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventdia2.setForeground(new java.awt.Color(255, 255, 255));
        TextEventdia2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventdia2.setText("25");
        TextEventdia2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonEvento2Layout = new javax.swing.GroupLayout(BotonEvento2);
        BotonEvento2.setLayout(BotonEvento2Layout);
        BotonEvento2Layout.setHorizontalGroup(
            BotonEvento2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes2, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
            .addComponent(TextEventdia2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BotonEvento2Layout.setVerticalGroup(
            BotonEvento2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonEvento2Layout.createSequentialGroup()
                .addComponent(TextEventmes2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextEventdia2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(BotonEvento2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 70, 60));

        TextEvento1Fecha1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextEvento1Fecha1.setText("Taylor Swift | The Eras Tour");
        Background.add(TextEvento1Fecha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, -1, -1));

        TextEvento2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextEvento2.setForeground(new java.awt.Color(102, 102, 102));
        TextEvento2.setText("Sat, 9 PM | Foro Sol México");
        Background.add(TextEvento2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, -1, -1));

        BotonEvento3.setBackground(new java.awt.Color(43, 50, 78));
        BotonEvento3.setForeground(new java.awt.Color(0, 0, 102));
        BotonEvento3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEvento3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonEvento3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonEvento3MouseExited(evt);
            }
        });

        TextEventmes3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventmes3.setForeground(new java.awt.Color(255, 255, 255));
        TextEventmes3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventmes3.setText("Aug");
        TextEventmes3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        TextEventdia3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventdia3.setForeground(new java.awt.Color(255, 255, 255));
        TextEventdia3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventdia3.setText("26");
        TextEventdia3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonEvento3Layout = new javax.swing.GroupLayout(BotonEvento3);
        BotonEvento3.setLayout(BotonEvento3Layout);
        BotonEvento3Layout.setHorizontalGroup(
            BotonEvento3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes3, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
            .addComponent(TextEventdia3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BotonEvento3Layout.setVerticalGroup(
            BotonEvento3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonEvento3Layout.createSequentialGroup()
                .addComponent(TextEventmes3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextEventdia3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(BotonEvento3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 70, 60));

        TextEvento1Fecha2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextEvento1Fecha2.setText("Taylor Swift | The Eras Tour");
        Background.add(TextEvento1Fecha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, -1, -1));

        TextEvento3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextEvento3.setForeground(new java.awt.Color(102, 102, 102));
        TextEvento3.setText("Fri, 9 PM | Foro Sol México");
        Background.add(TextEvento3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, 872, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //ParaConocer en donde esta clickando el mouse
    private void PanelHerramientasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PanelHerramientasMousePressed
    
    //Para conocer cuando el mouse es arrastrado
    private void PanelHerramientasMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PanelHerramientasMouseDragged

    private void TextCerrarXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseClicked
        System.exit(0);
    }//GEN-LAST:event_TextCerrarXMouseClicked

    private void TextCerrarXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseEntered
        BotonCerrar.setBackground(Color.red);
    }//GEN-LAST:event_TextCerrarXMouseEntered

    private void TextCerrarXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseExited
        BotonCerrar.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_TextCerrarXMouseExited

    private void BotonEvento1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento1MouseExited
  BotonEvento1.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonEvento1MouseExited

    private void BotonEvento1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento1MouseEntered
  BotonEvento1.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonEvento1MouseEntered

    private void BotonEvento1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento1MouseClicked
       
    //Envia al cliente al evento 1
    Event1 mEvent1 = new Event1();
    mEvent1.setVisible(true);  
    }//GEN-LAST:event_BotonEvento1MouseClicked

    private void BotonEvento2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento2MouseClicked
    
    //Envia al cliente al evento 2
    
    Event2 mEvent2 = new Event2();
    mEvent2.setVisible(true);  
    
    }//GEN-LAST:event_BotonEvento2MouseClicked

    private void BotonEvento2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento2MouseEntered
    BotonEvento2.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonEvento2MouseEntered

    private void BotonEvento2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento2MouseExited
    BotonEvento2.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonEvento2MouseExited

    private void BotonEvento3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento3MouseClicked
    
    //Envia al cliente al evento 3
    
    Event3 mEvent3 = new Event3();
    mEvent3.setVisible(true);  
    
    }//GEN-LAST:event_BotonEvento3MouseClicked

    private void BotonEvento3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento3MouseEntered
    BotonEvento3.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonEvento3MouseEntered

    private void BotonEvento3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento3MouseExited
    BotonEvento3.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonEvento3MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz3().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JPanel BotonCerrar;
    private javax.swing.JPanel BotonEvento1;
    private javax.swing.JPanel BotonEvento2;
    private javax.swing.JPanel BotonEvento3;
    private javax.swing.JLabel FondoTay;
    private javax.swing.JLabel NombreDeLaEmpresa;
    private javax.swing.JPanel PanelHerramientas;
    private javax.swing.JLabel TextCerrarX;
    private javax.swing.JLabel TextEventdia1;
    private javax.swing.JLabel TextEventdia2;
    private javax.swing.JLabel TextEventdia3;
    private javax.swing.JLabel TextEventmes1;
    private javax.swing.JLabel TextEventmes2;
    private javax.swing.JLabel TextEventmes3;
    private javax.swing.JLabel TextEvento1;
    private javax.swing.JLabel TextEvento1Fecha;
    private javax.swing.JLabel TextEvento1Fecha1;
    private javax.swing.JLabel TextEvento1Fecha2;
    private javax.swing.JLabel TextEvento2;
    private javax.swing.JLabel TextEvento3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel textIniciarSesion;
    // End of variables declaration//GEN-END:variables
}
