/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Proyecto;

import java.awt.Color;
import javax.swing.JOptionPane;

public class Interfaz extends javax.swing.JFrame {
    
    //Variables para conocer el Eje del cursor/parala barra de arriba
    int xMouse,yMouse;
            
    
    
    public Interfaz() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background = new javax.swing.JPanel();
        NombreDeLaEmpresa = new javax.swing.JLabel();
        FondoTay = new javax.swing.JLabel();
        textIniciarSesion = new javax.swing.JLabel();
        UsuNombre = new javax.swing.JTextField();
        TextNombre = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        UsuApellido = new javax.swing.JTextField();
        TextApellido = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        UsuUsuario = new javax.swing.JTextField();
        TextUsuario = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        UsuPass = new javax.swing.JTextField();
        TextPass = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        BotonLogin = new javax.swing.JPanel();
        TextEntrar = new javax.swing.JLabel();
        BotonCrearUsu = new javax.swing.JPanel();
        TextCrearUsu = new javax.swing.JLabel();
        PanelHerramientas = new javax.swing.JPanel();
        BotonCerrar = new javax.swing.JPanel();
        TextCerrarX = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        Background.setBackground(new java.awt.Color(255, 255, 255));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NombreDeLaEmpresa.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        NombreDeLaEmpresa.setForeground(new java.awt.Color(255, 255, 255));
        NombreDeLaEmpresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NombreDeLaEmpresa.setText("Productora de eventos Producciones Palace");
        NombreDeLaEmpresa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Background.add(NombreDeLaEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 280, 340, 20));

        FondoTay.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/FondoTay.jpg"))); // NOI18N
        FondoTay.setText("jLabel1");
        Background.add(FondoTay, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 480, 520));

        textIniciarSesion.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 36)); // NOI18N
        textIniciarSesion.setText("INICIAR SESIÓN");
        Background.add(textIniciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, -1, -1));

        UsuNombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuNombre.setForeground(new java.awt.Color(204, 204, 204));
        UsuNombre.setText("Ingrese su nombre");
        UsuNombre.setBorder(null);
        UsuNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuNombreMousePressed(evt);
            }
        });
        Background.add(UsuNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 290, -1));

        TextNombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextNombre.setText("NOMBRE");
        Background.add(TextNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 310, -1));

        UsuApellido.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuApellido.setForeground(new java.awt.Color(204, 204, 204));
        UsuApellido.setText("Ingrese su apellido");
        UsuApellido.setBorder(null);
        UsuApellido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                UsuApellidoMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuApellidoMousePressed(evt);
            }
        });
        Background.add(UsuApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 290, -1));

        TextApellido.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextApellido.setText("APELLIDO");
        Background.add(TextApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 310, -1));

        UsuUsuario.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuUsuario.setForeground(new java.awt.Color(204, 204, 204));
        UsuUsuario.setText("Ingrese su usuario");
        UsuUsuario.setBorder(null);
        UsuUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuUsuarioMousePressed(evt);
            }
        });
        Background.add(UsuUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, 290, -1));

        TextUsuario.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextUsuario.setText("USUARIO");
        Background.add(TextUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 310, -1));

        UsuPass.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuPass.setForeground(new java.awt.Color(204, 204, 204));
        UsuPass.setText("******");
        UsuPass.setBorder(null);
        UsuPass.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuPassMousePressed(evt);
            }
        });
        Background.add(UsuPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 290, -1));

        TextPass.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextPass.setText("CONTRASEÑA");
        Background.add(TextPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, -1, -1));

        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 310, -1));

        BotonLogin.setBackground(new java.awt.Color(43, 50, 78));
        BotonLogin.setForeground(new java.awt.Color(0, 0, 102));
        BotonLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonLoginMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonLoginMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonLoginMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BotonLoginMousePressed(evt);
            }
        });

        TextEntrar.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        TextEntrar.setForeground(new java.awt.Color(255, 255, 255));
        TextEntrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEntrar.setText("ENTRAR");
        TextEntrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonLoginLayout = new javax.swing.GroupLayout(BotonLogin);
        BotonLogin.setLayout(BotonLoginLayout);
        BotonLoginLayout.setHorizontalGroup(
            BotonLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEntrar, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
        );
        BotonLoginLayout.setVerticalGroup(
            BotonLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEntrar, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        Background.add(BotonLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, 110, 40));

        BotonCrearUsu.setBackground(new java.awt.Color(255, 255, 255));
        BotonCrearUsu.setForeground(new java.awt.Color(255, 255, 255));
        BotonCrearUsu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonCrearUsuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonCrearUsuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonCrearUsuMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BotonCrearUsuMousePressed(evt);
            }
        });

        TextCrearUsu.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        TextCrearUsu.setForeground(new java.awt.Color(136, 58, 72));
        TextCrearUsu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCrearUsu.setText("CREAR USUARIO");
        TextCrearUsu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonCrearUsuLayout = new javax.swing.GroupLayout(BotonCrearUsu);
        BotonCrearUsu.setLayout(BotonCrearUsuLayout);
        BotonCrearUsuLayout.setHorizontalGroup(
            BotonCrearUsuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonCrearUsuLayout.createSequentialGroup()
                .addComponent(TextCrearUsu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        BotonCrearUsuLayout.setVerticalGroup(
            BotonCrearUsuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCrearUsu, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
        );

        Background.add(BotonCrearUsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 90, 20));

        PanelHerramientas.setBackground(new java.awt.Color(255, 255, 255));
        PanelHerramientas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PanelHerramientasMouseDragged(evt);
            }
        });
        PanelHerramientas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PanelHerramientasMousePressed(evt);
            }
        });

        BotonCerrar.setBackground(new java.awt.Color(43, 50, 78));

        TextCerrarX.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        TextCerrarX.setForeground(new java.awt.Color(255, 255, 255));
        TextCerrarX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCerrarX.setText("X");
        TextCerrarX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TextCerrarX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BotonCerrarLayout = new javax.swing.GroupLayout(BotonCerrar);
        BotonCerrar.setLayout(BotonCerrarLayout);
        BotonCerrarLayout.setHorizontalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );
        BotonCerrarLayout.setVerticalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout PanelHerramientasLayout = new javax.swing.GroupLayout(PanelHerramientas);
        PanelHerramientas.setLayout(PanelHerramientasLayout);
        PanelHerramientasLayout.setHorizontalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 833, Short.MAX_VALUE))
        );
        PanelHerramientasLayout.setVerticalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(PanelHerramientas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //ParaConocer en donde esta clickando el mouse
    private void PanelHerramientasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PanelHerramientasMousePressed
    
    //Para conocer cuando el mouse es arrastrado
    private void PanelHerramientasMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PanelHerramientasMouseDragged

    private void TextCerrarXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseClicked
        System.exit(0);
    }//GEN-LAST:event_TextCerrarXMouseClicked

    private void TextCerrarXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseEntered
        BotonCerrar.setBackground(Color.red);
    }//GEN-LAST:event_TextCerrarXMouseEntered

    private void TextCerrarXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseExited
        BotonCerrar.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_TextCerrarXMouseExited

    private void UsuNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuNombreMousePressed
        if(UsuNombre.getText().equals("Ingrese su nombre")){
           UsuNombre.setText("");
           UsuNombre.setForeground(Color.black);
        }
        if (UsuApellido.getText().isEmpty()||UsuUsuario.getText().isEmpty() || UsuPass.getText().isEmpty()){
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
           
        }   
    }//GEN-LAST:event_UsuNombreMousePressed

    private void UsuApellidoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuApellidoMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_UsuApellidoMouseEntered

    private void UsuApellidoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuApellidoMousePressed
        if(UsuApellido.getText().equals("Ingrese su apellido")){
           UsuApellido.setText("");
           UsuApellido.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuUsuario.getText().isEmpty() || UsuPass.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_UsuApellidoMousePressed

    private void UsuUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuUsuarioMousePressed
        if(UsuUsuario.getText().equals("Ingrese su usuario")){
           UsuUsuario.setText("");
           UsuUsuario.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuApellido.getText().isEmpty() ||UsuPass.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
           
        }   
    }//GEN-LAST:event_UsuUsuarioMousePressed

    private void BotonLoginMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonLoginMouseExited
        BotonLogin.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonLoginMouseExited

    private void BotonLoginMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonLoginMouseEntered
        BotonLogin.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonLoginMouseEntered

    private void BotonLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonLoginMouseClicked
        
        //Manda a llamar la clase AlmacenamientoUsuario
        AlmacenamientoUsuario almaUsuario = new AlmacenamientoUsuario();
        
        //Almacena los usuario que ya existen
        
        AlmacenamientoUsuario[] arregloAlmacenamientoUsuario = new AlmacenamientoUsuario[10];
        arregloAlmacenamientoUsuario[0] = new AlmacenamientoUsuario();
        
        for (int contador = 0 ; contador < 10 ; contador ++){
            arregloAlmacenamientoUsuario[0] = new AlmacenamientoUsuario("David","Castillo","daveACM","dave@gmail.com","dave"); 
            arregloAlmacenamientoUsuario[1] = new AlmacenamientoUsuario("Andres","Cervantes","Andrew","andres@gmail.com","Andrew");        
            arregloAlmacenamientoUsuario[2] = new AlmacenamientoUsuario("Emily","McQuiddy","emiACM","emi@gmail.com","emi");  
            arregloAlmacenamientoUsuario[3] = new AlmacenamientoUsuario("Keren","Rojas","KerCR","Ker@gmail.com","ker"); 
            
            //Manda a llamar el nuevo usuario que se creo en crear usuario
            
            Interfaz2 mInterfaz2 = new Interfaz2();
            
            
            //Termina de recorrer el arreglo de almacenamientoUsuarios
            
            arregloAlmacenamientoUsuario[contador] = new AlmacenamientoUsuario();
        }
        //Pasa los los fieldtext a String para poder evaluarlos
       
        String Nombre = UsuNombre.getText();
        String Apellido = UsuApellido.getText();
        String Usuario = UsuUsuario.getText();
        String Password = UsuPass.getText();
      
  
        
        //Autentica que la info que ingresa el cliente se encuentre dentro 
        
        for (int contador = 0; contador < 10; contador++) {
        if (Nombre.equals(arregloAlmacenamientoUsuario[contador].getNombre()) && Apellido.equals(arregloAlmacenamientoUsuario[contador].getApellido())&& Usuario.equals(arregloAlmacenamientoUsuario[contador].getUsuario())&& Password.equals(arregloAlmacenamientoUsuario[contador].getPassword())){
         Interfaz3 mInterfaz3 = new Interfaz3();
         mInterfaz3.setVisible(true);
         
            } 
        }
    }//GEN-LAST:event_BotonLoginMouseClicked

    private void BotonLoginMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonLoginMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_BotonLoginMousePressed

    private void UsuPassMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuPassMousePressed
        if(UsuPass.getText().equals("******")){
           UsuPass.setText("");
           UsuPass.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuApellido.getText().isEmpty() ||UsuUsuario.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
        }   
    }//GEN-LAST:event_UsuPassMousePressed

    private void BotonCrearUsuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonCrearUsuMouseClicked
         Interfaz2 mInterfaz2 = new Interfaz2();
         mInterfaz2.setVisible(true);
         
    }//GEN-LAST:event_BotonCrearUsuMouseClicked

    private void BotonCrearUsuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonCrearUsuMouseEntered
        BotonCrearUsu.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonCrearUsuMouseEntered

    private void BotonCrearUsuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonCrearUsuMouseExited
        BotonCrearUsu.setBackground(Color.white);
    }//GEN-LAST:event_BotonCrearUsuMouseExited

    private void BotonCrearUsuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonCrearUsuMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_BotonCrearUsuMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JPanel BotonCerrar;
    private javax.swing.JPanel BotonCrearUsu;
    private javax.swing.JPanel BotonLogin;
    private javax.swing.JLabel FondoTay;
    private javax.swing.JLabel NombreDeLaEmpresa;
    private javax.swing.JPanel PanelHerramientas;
    private javax.swing.JLabel TextApellido;
    private javax.swing.JLabel TextCerrarX;
    private javax.swing.JLabel TextCrearUsu;
    private javax.swing.JLabel TextEntrar;
    private javax.swing.JLabel TextNombre;
    private javax.swing.JLabel TextPass;
    private javax.swing.JLabel TextUsuario;
    private javax.swing.JTextField UsuApellido;
    private javax.swing.JTextField UsuNombre;
    private javax.swing.JTextField UsuPass;
    private javax.swing.JTextField UsuUsuario;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel textIniciarSesion;
    // End of variables declaration//GEN-END:variables
}
