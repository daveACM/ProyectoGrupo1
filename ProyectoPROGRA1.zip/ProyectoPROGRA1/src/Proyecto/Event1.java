  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Proyecto;
import javax.swing.JOptionPane;

import java.awt.Color;


public class Event1 extends javax.swing.JFrame {
    
    //Variables para conocer el Eje del cursor/parala barra de arriba
    int xMouse,yMouse;
            
    
    
    public Event1() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background = new javax.swing.JPanel();
        NombreDeLaEmpresa = new javax.swing.JLabel();
        FondoTay = new javax.swing.JLabel();
        textIniciarSesion = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        BotonEvento1 = new javax.swing.JPanel();
        TextEventmes1 = new javax.swing.JLabel();
        TextEventdia1 = new javax.swing.JLabel();
        TextEvento1Fecha = new javax.swing.JLabel();
        TextEvento1 = new javax.swing.JLabel();
        PanelHerramientas = new javax.swing.JPanel();
        BotonCerrar = new javax.swing.JPanel();
        TextCerrarX = new javax.swing.JLabel();
        BotonRegresarEventos = new javax.swing.JPanel();
        TextEventmes2 = new javax.swing.JLabel();
        TextNombreEvento = new javax.swing.JLabel();
        TextNomEvent = new javax.swing.JLabel();
        TextCiudadEvento = new javax.swing.JLabel();
        TextCiuEvento = new javax.swing.JLabel();
        TextDireccionEvento = new javax.swing.JLabel();
        TextDirecEvento = new javax.swing.JLabel();
        TextCategoriaEvento = new javax.swing.JLabel();
        TextCateEvento1 = new javax.swing.JLabel();
        TextFechaEvento = new javax.swing.JLabel();
        TextDateEvento = new javax.swing.JLabel();
        BotonReservarEvento = new javax.swing.JPanel();
        TextEventmes3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        Background.setBackground(new java.awt.Color(255, 255, 255));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NombreDeLaEmpresa.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        NombreDeLaEmpresa.setForeground(new java.awt.Color(255, 255, 255));
        NombreDeLaEmpresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NombreDeLaEmpresa.setText("Productora de eventos Producciones Palace");
        NombreDeLaEmpresa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Background.add(NombreDeLaEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 100, 340, 20));

        FondoTay.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/TaylorConcert.jpg"))); // NOI18N
        FondoTay.setText("jLabel1");
        Background.add(FondoTay, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 490, 530));

        textIniciarSesion.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 36)); // NOI18N
        textIniciarSesion.setText("EVENTO");
        Background.add(textIniciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 310, -1));

        BotonEvento1.setBackground(new java.awt.Color(43, 50, 78));
        BotonEvento1.setForeground(new java.awt.Color(0, 0, 102));
        BotonEvento1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEvento1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonEvento1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonEvento1MouseExited(evt);
            }
        });

        TextEventmes1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventmes1.setForeground(new java.awt.Color(255, 255, 255));
        TextEventmes1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventmes1.setText("Aug");
        TextEventmes1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        TextEventdia1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 24)); // NOI18N
        TextEventdia1.setForeground(new java.awt.Color(255, 255, 255));
        TextEventdia1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventdia1.setText("24");
        TextEventdia1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonEvento1Layout = new javax.swing.GroupLayout(BotonEvento1);
        BotonEvento1.setLayout(BotonEvento1Layout);
        BotonEvento1Layout.setHorizontalGroup(
            BotonEvento1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes1, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
            .addComponent(TextEventdia1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BotonEvento1Layout.setVerticalGroup(
            BotonEvento1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonEvento1Layout.createSequentialGroup()
                .addComponent(TextEventmes1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextEventdia1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(BotonEvento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 70, 60));

        TextEvento1Fecha.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextEvento1Fecha.setText("Taylor Swift | The Eras Tour");
        Background.add(TextEvento1Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, -1, -1));

        TextEvento1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextEvento1.setForeground(new java.awt.Color(102, 102, 102));
        TextEvento1.setText("Thu, 9 PM | Foro Sol México");
        Background.add(TextEvento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, -1, -1));

        PanelHerramientas.setBackground(new java.awt.Color(255, 255, 255));
        PanelHerramientas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PanelHerramientasMouseDragged(evt);
            }
        });
        PanelHerramientas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PanelHerramientasMousePressed(evt);
            }
        });

        BotonCerrar.setBackground(new java.awt.Color(43, 50, 78));

        TextCerrarX.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        TextCerrarX.setForeground(new java.awt.Color(255, 255, 255));
        TextCerrarX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCerrarX.setText("X");
        TextCerrarX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TextCerrarX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BotonCerrarLayout = new javax.swing.GroupLayout(BotonCerrar);
        BotonCerrar.setLayout(BotonCerrarLayout);
        BotonCerrarLayout.setHorizontalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );
        BotonCerrarLayout.setVerticalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout PanelHerramientasLayout = new javax.swing.GroupLayout(PanelHerramientas);
        PanelHerramientas.setLayout(PanelHerramientasLayout);
        PanelHerramientasLayout.setHorizontalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 833, Short.MAX_VALUE))
        );
        PanelHerramientasLayout.setVerticalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(PanelHerramientas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 30));

        BotonRegresarEventos.setBackground(new java.awt.Color(43, 50, 78));
        BotonRegresarEventos.setForeground(new java.awt.Color(0, 0, 102));
        BotonRegresarEventos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegresarEventosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonRegresarEventosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonRegresarEventosMouseExited(evt);
            }
        });

        TextEventmes2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        TextEventmes2.setForeground(new java.awt.Color(255, 255, 255));
        TextEventmes2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventmes2.setText("VER OTROS EVENTOS");
        TextEventmes2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonRegresarEventosLayout = new javax.swing.GroupLayout(BotonRegresarEventos);
        BotonRegresarEventos.setLayout(BotonRegresarEventosLayout);
        BotonRegresarEventosLayout.setHorizontalGroup(
            BotonRegresarEventosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        BotonRegresarEventosLayout.setVerticalGroup(
            BotonRegresarEventosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes2, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        Background.add(BotonRegresarEventos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, 140, 30));

        TextNombreEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextNombreEvento.setText("Nombre del evento:  ");
        Background.add(TextNombreEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        TextNomEvent.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextNomEvent.setForeground(new java.awt.Color(102, 102, 102));
        TextNomEvent.setText("The Eras Tour");
        Background.add(TextNomEvent, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, -1, -1));

        TextCiudadEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextCiudadEvento.setText("Ciudad:");
        Background.add(TextCiudadEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, -1, -1));

        TextCiuEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextCiuEvento.setForeground(new java.awt.Color(102, 102, 102));
        TextCiuEvento.setText("DF");
        Background.add(TextCiuEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 230, -1, -1));

        TextDireccionEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextDireccionEvento.setText("Dirección:");
        Background.add(TextDireccionEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        TextDirecEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextDirecEvento.setForeground(new java.awt.Color(102, 102, 102));
        TextDirecEvento.setText("Foro Sol, Mexico, DF, MX");
        Background.add(TextDirecEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, -1, -1));

        TextCategoriaEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextCategoriaEvento.setText("Categoria:");
        Background.add(TextCategoriaEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, -1));

        TextCateEvento1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextCateEvento1.setForeground(new java.awt.Color(102, 102, 102));
        TextCateEvento1.setText("16+");
        Background.add(TextCateEvento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, -1, -1));

        TextFechaEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 17)); // NOI18N
        TextFechaEvento.setText("Fecha:");
        Background.add(TextFechaEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));

        TextDateEvento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 16)); // NOI18N
        TextDateEvento.setForeground(new java.awt.Color(102, 102, 102));
        TextDateEvento.setText("Aug 24, Thu");
        Background.add(TextDateEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 350, -1, -1));

        BotonReservarEvento.setBackground(new java.awt.Color(136, 58, 72));
        BotonReservarEvento.setForeground(new java.awt.Color(0, 0, 102));
        BotonReservarEvento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonReservarEventoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonReservarEventoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonReservarEventoMouseExited(evt);
            }
        });

        TextEventmes3.setBackground(new java.awt.Color(136, 58, 72));
        TextEventmes3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        TextEventmes3.setForeground(new java.awt.Color(255, 255, 255));
        TextEventmes3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEventmes3.setText("RESERVAR");
        TextEventmes3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonReservarEventoLayout = new javax.swing.GroupLayout(BotonReservarEvento);
        BotonReservarEvento.setLayout(BotonReservarEventoLayout);
        BotonReservarEventoLayout.setHorizontalGroup(
            BotonReservarEventoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes3, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        BotonReservarEventoLayout.setVerticalGroup(
            BotonReservarEventoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEventmes3, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        Background.add(BotonReservarEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 410, 100, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, 872, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //ParaConocer en donde esta clickando el mouse
    private void PanelHerramientasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PanelHerramientasMousePressed
    
    //Para conocer cuando el mouse es arrastrado
    private void PanelHerramientasMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PanelHerramientasMouseDragged

    private void TextCerrarXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseClicked
        System.exit(0);
    }//GEN-LAST:event_TextCerrarXMouseClicked

    private void TextCerrarXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseEntered
        BotonCerrar.setBackground(Color.red);
    }//GEN-LAST:event_TextCerrarXMouseEntered

    private void TextCerrarXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseExited
        BotonCerrar.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_TextCerrarXMouseExited

    private void BotonEvento1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento1MouseExited
  BotonEvento1.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonEvento1MouseExited

    private void BotonEvento1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento1MouseEntered
  BotonEvento1.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonEvento1MouseEntered

    private void BotonEvento1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEvento1MouseClicked
        
        //Boton Mostrar info
        
        
    }//GEN-LAST:event_BotonEvento1MouseClicked

    private void BotonRegresarEventosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegresarEventosMouseClicked
    Interfaz3 mInterfaz3 = new Interfaz3();
    mInterfaz3.setVisible(true); 
    }//GEN-LAST:event_BotonRegresarEventosMouseClicked

    private void BotonRegresarEventosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegresarEventosMouseEntered
    BotonRegresarEventos.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonRegresarEventosMouseEntered

    private void BotonRegresarEventosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegresarEventosMouseExited
    BotonRegresarEventos.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonRegresarEventosMouseExited

    private void BotonReservarEventoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonReservarEventoMouseClicked
        
        // Manda a llamar al metodo para guardar la reserva del evento
        
        Evento[] arregloEvento = new Evento[2];
        arregloEvento[0] = new Evento();
        for (int contador = 0 ; contador < 2 ; contador ++){
            arregloEvento[0] = new Evento("The Eras Tour","DF","Foro Sol, Mexico, DF, MX","16+","Aug 24, Thu",100,60); 
             
            
            arregloEvento[contador] = new Evento();
        }
        
        // Muestra la reserva que se hizo
        
         JOptionPane.showMessageDialog(null, "Detalles de su reservacion"+"\n"+"Nombre del evento: "+arregloEvento[0].getNombre()+"\n"+ " Ciudad: " + arregloEvento[0].getCiudad()+"\n"+" Direccion  : "+arregloEvento[0].getDireccion()+"\n"+" Categoria: " +arregloEvento[0].getCategoria() +"\n "+"Fecha: "+arregloEvento[0].getFecha()+"\n"+"Capacidad Disponble:"+arregloEvento[0].getCapacidadDisponible());
        
    }//GEN-LAST:event_BotonReservarEventoMouseClicked

    private void BotonReservarEventoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonReservarEventoMouseEntered
    BotonReservarEvento.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonReservarEventoMouseEntered

    private void BotonReservarEventoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonReservarEventoMouseExited
    BotonReservarEvento.setBackground(new Color(136,58,72));
    }//GEN-LAST:event_BotonReservarEventoMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Event1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Event1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Event1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Event1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Event1().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JPanel BotonCerrar;
    private javax.swing.JPanel BotonEvento1;
    private javax.swing.JPanel BotonRegresarEventos;
    private javax.swing.JPanel BotonReservarEvento;
    private javax.swing.JLabel FondoTay;
    private javax.swing.JLabel NombreDeLaEmpresa;
    private javax.swing.JPanel PanelHerramientas;
    private javax.swing.JLabel TextCateEvento1;
    private javax.swing.JLabel TextCategoriaEvento;
    private javax.swing.JLabel TextCerrarX;
    private javax.swing.JLabel TextCiuEvento;
    private javax.swing.JLabel TextCiudadEvento;
    private javax.swing.JLabel TextDateEvento;
    private javax.swing.JLabel TextDirecEvento;
    private javax.swing.JLabel TextDireccionEvento;
    private javax.swing.JLabel TextEventdia1;
    private javax.swing.JLabel TextEventmes1;
    private javax.swing.JLabel TextEventmes2;
    private javax.swing.JLabel TextEventmes3;
    private javax.swing.JLabel TextEvento1;
    private javax.swing.JLabel TextEvento1Fecha;
    private javax.swing.JLabel TextFechaEvento;
    private javax.swing.JLabel TextNomEvent;
    private javax.swing.JLabel TextNombreEvento;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel textIniciarSesion;
    // End of variables declaration//GEN-END:variables
}
