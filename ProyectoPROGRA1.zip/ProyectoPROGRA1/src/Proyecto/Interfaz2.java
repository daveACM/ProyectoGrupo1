  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Proyecto;
import javax.swing.JOptionPane;

import java.awt.Color;


public class Interfaz2 extends javax.swing.JFrame {
    
    //Variables para conocer el Eje del cursor/parala barra de arriba
    int xMouse,yMouse;
            
    
    
    public Interfaz2() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background = new javax.swing.JPanel();
        NombreDeLaEmpresa = new javax.swing.JLabel();
        FondoTay = new javax.swing.JLabel();
        textIniciarSesion = new javax.swing.JLabel();
        UsuNombre = new javax.swing.JTextField();
        TextNombre = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        UsuApellido = new javax.swing.JTextField();
        TextApellido = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        UsuUsuario = new javax.swing.JTextField();
        TextUsuario = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        TextPass = new javax.swing.JLabel();
        UsuPass = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        BotonMostrar = new javax.swing.JPanel();
        TextEntrar = new javax.swing.JLabel();
        PanelHerramientas = new javax.swing.JPanel();
        BotonCerrar = new javax.swing.JPanel();
        TextCerrarX = new javax.swing.JLabel();
        TextCorreo = new javax.swing.JLabel();
        UsuCorreo = new javax.swing.JTextField();
        jSeparator6 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        Background.setBackground(new java.awt.Color(255, 255, 255));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NombreDeLaEmpresa.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        NombreDeLaEmpresa.setForeground(new java.awt.Color(255, 255, 255));
        NombreDeLaEmpresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NombreDeLaEmpresa.setText("Productora de eventos Producciones Palace");
        NombreDeLaEmpresa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Background.add(NombreDeLaEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 340, 20));

        FondoTay.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/FondoTay2 - copia.jpeg"))); // NOI18N
        FondoTay.setText("jLabel1");
        Background.add(FondoTay, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 490, 530));

        textIniciarSesion.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 36)); // NOI18N
        textIniciarSesion.setText("CREAR USUARIO");
        Background.add(textIniciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1, -1));

        UsuNombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuNombre.setForeground(new java.awt.Color(204, 204, 204));
        UsuNombre.setText("Ingrese su nombre");
        UsuNombre.setBorder(null);
        UsuNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuNombreMousePressed(evt);
            }
        });
        Background.add(UsuNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 290, -1));

        TextNombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextNombre.setText("NOMBRE");
        Background.add(TextNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 310, -1));

        UsuApellido.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuApellido.setForeground(new java.awt.Color(204, 204, 204));
        UsuApellido.setText("Ingrese su apellido");
        UsuApellido.setBorder(null);
        UsuApellido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                UsuApellidoMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuApellidoMousePressed(evt);
            }
        });
        Background.add(UsuApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 290, -1));

        TextApellido.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextApellido.setText("APELLIDO");
        Background.add(TextApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, -1, -1));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 310, -1));

        UsuUsuario.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuUsuario.setForeground(new java.awt.Color(204, 204, 204));
        UsuUsuario.setText("Ingrese su usuario");
        UsuUsuario.setBorder(null);
        UsuUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuUsuarioMousePressed(evt);
            }
        });
        Background.add(UsuUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 290, -1));

        TextUsuario.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextUsuario.setText("USUARIO");
        Background.add(TextUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, -1, -1));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 310, -1));

        TextPass.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextPass.setText("CONTRASEÑA");
        Background.add(TextPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));

        UsuPass.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuPass.setForeground(new java.awt.Color(204, 204, 204));
        UsuPass.setText("******");
        UsuPass.setBorder(null);
        UsuPass.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuPassMousePressed(evt);
            }
        });
        Background.add(UsuPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 290, -1));

        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, 310, -1));

        BotonMostrar.setBackground(new java.awt.Color(43, 50, 78));
        BotonMostrar.setForeground(new java.awt.Color(0, 0, 102));
        BotonMostrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonMostrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonMostrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonMostrarMouseExited(evt);
            }
        });

        TextEntrar.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        TextEntrar.setForeground(new java.awt.Color(255, 255, 255));
        TextEntrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextEntrar.setText("REGISTRAR");
        TextEntrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonMostrarLayout = new javax.swing.GroupLayout(BotonMostrar);
        BotonMostrar.setLayout(BotonMostrarLayout);
        BotonMostrarLayout.setHorizontalGroup(
            BotonMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEntrar, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
        );
        BotonMostrarLayout.setVerticalGroup(
            BotonMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextEntrar, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        Background.add(BotonMostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 110, 40));

        PanelHerramientas.setBackground(new java.awt.Color(255, 255, 255));
        PanelHerramientas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PanelHerramientasMouseDragged(evt);
            }
        });
        PanelHerramientas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PanelHerramientasMousePressed(evt);
            }
        });

        BotonCerrar.setBackground(new java.awt.Color(43, 50, 78));

        TextCerrarX.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        TextCerrarX.setForeground(new java.awt.Color(255, 255, 255));
        TextCerrarX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCerrarX.setText("X");
        TextCerrarX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TextCerrarX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TextCerrarXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BotonCerrarLayout = new javax.swing.GroupLayout(BotonCerrar);
        BotonCerrar.setLayout(BotonCerrarLayout);
        BotonCerrarLayout.setHorizontalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );
        BotonCerrarLayout.setVerticalGroup(
            BotonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TextCerrarX, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout PanelHerramientasLayout = new javax.swing.GroupLayout(PanelHerramientas);
        PanelHerramientas.setLayout(PanelHerramientasLayout);
        PanelHerramientasLayout.setHorizontalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 833, Short.MAX_VALUE))
        );
        PanelHerramientasLayout.setVerticalGroup(
            PanelHerramientasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHerramientasLayout.createSequentialGroup()
                .addComponent(BotonCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Background.add(PanelHerramientas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 30));

        TextCorreo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        TextCorreo.setText("CORREO");
        Background.add(TextCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

        UsuCorreo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        UsuCorreo.setForeground(new java.awt.Color(204, 204, 204));
        UsuCorreo.setText("Ingrese su correo");
        UsuCorreo.setBorder(null);
        UsuCorreo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                UsuCorreoMousePressed(evt);
            }
        });
        Background.add(UsuCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 290, -1));

        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 310, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, 872, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //ParaConocer en donde esta clickando el mouse
    private void PanelHerramientasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PanelHerramientasMousePressed
    
    //Para conocer cuando el mouse es arrastrado
    private void PanelHerramientasMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHerramientasMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PanelHerramientasMouseDragged

    private void TextCerrarXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseClicked
        System.exit(0);
    }//GEN-LAST:event_TextCerrarXMouseClicked

    private void TextCerrarXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseEntered
        BotonCerrar.setBackground(Color.red);
    }//GEN-LAST:event_TextCerrarXMouseEntered

    private void TextCerrarXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextCerrarXMouseExited
        BotonCerrar.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_TextCerrarXMouseExited

    private void UsuNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuNombreMousePressed
        if(UsuNombre.getText().equals("Ingrese su nombre")){
           UsuNombre.setText("");
           UsuNombre.setForeground(Color.black);
        }
        if (UsuApellido.getText().isEmpty()||UsuUsuario.getText().isEmpty() || UsuPass.getText().isEmpty() || UsuCorreo.getText().isEmpty()){
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
           UsuCorreo.setText("Ingrese su correo");
           UsuCorreo.setForeground(new Color(204,204,204));
           
        }   
    }//GEN-LAST:event_UsuNombreMousePressed

    private void UsuApellidoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuApellidoMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_UsuApellidoMouseEntered

    private void UsuApellidoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuApellidoMousePressed
        if(UsuApellido.getText().equals("Ingrese su apellido")){
           UsuApellido.setText("");
           UsuApellido.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuUsuario.getText().isEmpty() || UsuPass.getText().isEmpty() || UsuCorreo.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
           UsuCorreo.setText("Ingrese su correo");
           UsuCorreo.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_UsuApellidoMousePressed

    private void UsuUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuUsuarioMousePressed
        if(UsuUsuario.getText().equals("Ingrese su usuario")){
           UsuUsuario.setText("");
           UsuUsuario.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuApellido.getText().isEmpty() ||UsuPass.getText().isEmpty() || UsuCorreo.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
           UsuCorreo.setText("Ingrese su correo");
           UsuCorreo.setForeground(new Color(204,204,204));
           
        }   
    }//GEN-LAST:event_UsuUsuarioMousePressed

    private void BotonMostrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonMostrarMouseExited
  BotonMostrar.setBackground(new Color(43,50,78));
    }//GEN-LAST:event_BotonMostrarMouseExited

    private void BotonMostrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonMostrarMouseEntered
  BotonMostrar.setBackground(new Color(244,204,143));
    }//GEN-LAST:event_BotonMostrarMouseEntered

    private void BotonMostrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonMostrarMouseClicked
        
        //Manda a llamar la Clase AlmacenamientUsuario
        
        AlmacenamientoUsuario almaUsuario = new AlmacenamientoUsuario();
        
        
        //Pasa las variables de Textfield a variables string
        //Y guarda la info ingresa para un nuevo usuario
        
        String Nombre = UsuNombre.getText();
        almaUsuario.setNombre(Nombre);
        
        String Apellido = UsuApellido.getText();
        almaUsuario.setApellido(Apellido);
        
        String Usuario = UsuUsuario.getText();
        almaUsuario.setUsuario(Usuario);
        
        
        String Correo = UsuCorreo.getText();
        almaUsuario.setCorreo(Correo);
        
        String Password = UsuPass.getText();
        almaUsuario.setPassword(Password);
        
        // Guarda la info en la clase Almacenamiento Usuario
        
        AlmacenamientoUsuario[] arregloAlmacenamientoUsuario = new AlmacenamientoUsuario[10];
        arregloAlmacenamientoUsuario[0] = new AlmacenamientoUsuario();
        
        for (int contador = 0 ; contador < 10 ; contador ++){
            arregloAlmacenamientoUsuario[0] = new AlmacenamientoUsuario("David","Castillo","daveACM","dave@gmail.com","dave"); 
            arregloAlmacenamientoUsuario[1] = new AlmacenamientoUsuario("Andres","Cervantes","Andrew","andres@gmail.com","Andrew");        
            arregloAlmacenamientoUsuario[2] = new AlmacenamientoUsuario("Emily","McQuiddy","emiACM","emi@gmail.com","emi");  
            arregloAlmacenamientoUsuario[3] = new AlmacenamientoUsuario("Keren","Rojas","KerCR","Ker@gmail.com","ker"); 
            
            arregloAlmacenamientoUsuario[4] = new AlmacenamientoUsuario(almaUsuario.getNombre(),almaUsuario.getApellido(),almaUsuario.getUsuario(),almaUsuario.getCorreo(),almaUsuario.getPassword());  
            
            arregloAlmacenamientoUsuario[contador] = new AlmacenamientoUsuario();
        }
        
        // Muestra los usuario que existen
        
        for (int contador = 0; contador < 10; contador++) {
            System.out.println("Nombre: "+arregloAlmacenamientoUsuario[contador].getNombre()+"  Apellido: " + arregloAlmacenamientoUsuario[contador].getApellido()+"  Usuario: "+arregloAlmacenamientoUsuario[contador].getUsuario()+" Correo: " +arregloAlmacenamientoUsuario[contador].getCorreo() + " Password: "+arregloAlmacenamientoUsuario[contador].getPassword());
        }
         JOptionPane.showMessageDialog(null, "Informacion del nuevo usuario registrado"+"\n"+"Nombre: "+arregloAlmacenamientoUsuario[4].Nombre +"\n"+"Apellido: "+arregloAlmacenamientoUsuario[4].getApellido()+"\n"+"Usuario: "+arregloAlmacenamientoUsuario[4].getUsuario()+"\n"+"Correo: "+arregloAlmacenamientoUsuario[4].getCorreo());
         Interfaz mInterfaz = new Interfaz();
         mInterfaz.setVisible(true);
        
        
    }//GEN-LAST:event_BotonMostrarMouseClicked

    private void UsuPassMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuPassMousePressed
        if(UsuPass.getText().equals("******")){
           UsuPass.setText("");
           UsuPass.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuApellido.getText().isEmpty() ||UsuUsuario.getText().isEmpty() || UsuCorreo.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
           UsuCorreo.setText("Ingrese su correo");
           UsuCorreo.setForeground(new Color(204,204,204));
           
        }   
    }//GEN-LAST:event_UsuPassMousePressed

    private void UsuCorreoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsuCorreoMousePressed
        if(UsuCorreo.getText().equals("Ingrese su correo")){
           UsuCorreo.setText("");
           UsuCorreo.setForeground(Color.black);
        
        }
        if(UsuNombre.getText().isEmpty() || UsuApellido.getText().isEmpty() ||UsuUsuario.getText().isEmpty() || UsuPass.getText().isEmpty()){
           UsuNombre.setText("Ingrese su nombre");
           UsuNombre.setForeground(new Color(204,204,204));
           UsuApellido.setText("Ingrese su apellido");
           UsuApellido.setForeground(new Color(204,204,204));
           UsuUsuario.setText("Ingrese su usuario");
           UsuUsuario.setForeground(new Color(204,204,204));
           UsuPass.setText("******");
           UsuPass.setForeground(new Color(204,204,204));
           
        } 
    }//GEN-LAST:event_UsuCorreoMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz2().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JPanel BotonCerrar;
    private javax.swing.JPanel BotonMostrar;
    private javax.swing.JLabel FondoTay;
    private javax.swing.JLabel NombreDeLaEmpresa;
    private javax.swing.JPanel PanelHerramientas;
    private javax.swing.JLabel TextApellido;
    private javax.swing.JLabel TextCerrarX;
    private javax.swing.JLabel TextCorreo;
    private javax.swing.JLabel TextEntrar;
    private javax.swing.JLabel TextNombre;
    private javax.swing.JLabel TextPass;
    private javax.swing.JLabel TextUsuario;
    private javax.swing.JTextField UsuApellido;
    private javax.swing.JTextField UsuCorreo;
    private javax.swing.JTextField UsuNombre;
    private javax.swing.JTextField UsuPass;
    private javax.swing.JTextField UsuUsuario;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JLabel textIniciarSesion;
    // End of variables declaration//GEN-END:variables
}
