/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

/**
 *
 * @author XSF
 */
public class Evento {
    public String nombre;
    public String ciudad;
    public String direccion;
    public String categoria;
    public String fecha;
    public int capacidadTotal;
    public int capacidadDisponible;

    public Evento(String nombre, String ciudad, String direccion, String categoria, String fecha, int capacidadTotal, int capacidadDisponible) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.categoria = categoria;
        this.fecha = fecha;
        this.capacidadTotal = capacidadTotal;
        this.capacidadDisponible = capacidadDisponible;
    }
    
    public Evento(){
    
    
    }

    // Getters y Setters para cada campo
    // ...
    
    public void reservarAsiento() {
        if (capacidadDisponible > 0) {
            capacidadDisponible--;
        } else {
            System.out.println("No hay asientos disponibles");
        }
    }
    
    //Getters 
    public String getNombre(){
     return nombre;
    }
    
    public String getCiudad(){
     return ciudad;
    }
    
    public String getDireccion(){
     return direccion;
    }
    
    public String getCategoria(){
     return categoria;
    }
    
    public String getFecha(){
     return fecha;
    }
    
    public int getCapacidatotal(){
     return capacidadTotal;
    }
    
    public int getCapacidadDisponible(){
     return capacidadDisponible;
    }
    
    //Setters
    
    public void setCapacidadTotal(int nuevaCapacidadTotal) {
     capacidadTotal = nuevaCapacidadTotal;
    }
    
    public void setFecha(String nuevaFecha) {
     fecha = nuevaFecha;
    }
    
    public void setCategoria(String nuevaCategoria) {
     categoria = nuevaCategoria;
    }
    
    public void setCiudad(String nuevaCiudad) {
     ciudad = nuevaCiudad;
    }
    
    public void setDireccion(String nuevaDireccion) {
     direccion = nuevaDireccion;
    }
    
    public void setNombre(String nuevoNombre) {
     nombre = nuevoNombre; 
    }
    
    public void setCapacidadDisponible(int i) {
     capacidadDisponible = i;
    }
}
