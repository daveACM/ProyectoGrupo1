/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;
import Proyecto.Evento;
/**
 *
 * @author XSF
 */
public class Eliminar {
    public void eliminarEvento(Evento evento) {
        evento.setNombre(null);
        evento.setCiudad(null);
        evento.setDireccion(null);
        evento.setCategoria(null);
        evento.setFecha(null);
        evento.setCapacidadTotal(0);
        evento.setCapacidadDisponible(0);
    }
}
